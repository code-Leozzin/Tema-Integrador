import express from 'express';
import { Item } from '@prisma/client';
import prisma from '../prisma';

const router = express.Router();

// GET - Listar todos os itens
router.get('/', async (req, res) => {
  try {
    const items = await prisma.item.findMany({
      include: { 
        collection: true 
      }
    });
    res.json(items);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar itens', details: error });
  }
});

// GET - Buscar um item específico por ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const item = await prisma.item.findUnique({
      where: { id: Number(id) },
      include: { collection: true }
    });
    
    if (!item) {
      return res.status(404).json({ error: 'Item não encontrado' });
    }
    
    res.json(item);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar item', details: error });
  }
});

// GET - Listar itens de uma coleção específica
router.get('/collection/:collectionId', async (req, res) => {
  try {
    const { collectionId } = req.params;
    const items = await prisma.item.findMany({
      where: { collectionId: Number(collectionId) }
    });
    
    res.json(items);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar itens da coleção', details: error });
  }
});

// POST - Criar um novo item
router.post('/', async (req, res) => {
  try {
    const { name, description, imageUrl, collectionId } = req.body;
    
    if (!name || !collectionId) {
      return res.status(400).json({ error: 'Nome e ID da coleção são obrigatórios' });
    }
    
    // Verificar se a coleção existe
    const collectionExists = await prisma.collection.findUnique({
      where: { id: Number(collectionId) }
    });
    
    if (!collectionExists) {
      return res.status(404).json({ error: 'Coleção não encontrada' });
    }
    
    const newItem = await prisma.item.create({
      data: {
        name,
        description,
        imageUrl,
        collectionId: Number(collectionId)
      }
    });
    
    res.status(201).json(newItem);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao criar item', details: error });
  }
});

// PUT - Atualizar um item existente
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, imageUrl, collectionId } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: 'Nome do item é obrigatório' });
    }
    
    // Se collectionId foi fornecido, verificar se a coleção existe
    if (collectionId) {
      const collectionExists = await prisma.collection.findUnique({
        where: { id: Number(collectionId) }
      });
      
      if (!collectionExists) {
        return res.status(404).json({ error: 'Coleção não encontrada' });
      }
    }
    
    const updatedItem = await prisma.item.update({
      where: { id: Number(id) },
      data: {
        name,
        description,
        imageUrl,
        ...(collectionId && { collectionId: Number(collectionId) })
      }
    });
    
    res.json(updatedItem);
  } catch (error) {
    if (error.code === 'P2025') {
      return res.status(404).json({ error: 'Item não encontrado' });
    }
    res.status(500).json({ error: 'Erro ao atualizar item', details: error });
  }
});

// DELETE - Remover um item
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    await prisma.item.delete({
      where: { id: Number(id) }
    });
    
    res.status(204).send();
  } catch (error) {
    if (error.code === 'P2025') {
      return res.status(404).json({ error: 'Item não encontrado' });
    }
    res.status(500).json({ error: 'Erro ao excluir item', details: error });
  }
});

export default router;
