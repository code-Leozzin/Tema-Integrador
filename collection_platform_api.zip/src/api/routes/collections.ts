import express from 'express';
import { Collection } from '@prisma/client';
import prisma from '../prisma';

const router = express.Router();

// GET - Listar todas as coleções
router.get('/', async (req, res) => {
  try {
    const collections = await prisma.collection.findMany({
      include: { 
        items: true 
      }
    });
    res.json(collections);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar coleções', details: error });
  }
});

// GET - Buscar uma coleção específica por ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const collection = await prisma.collection.findUnique({
      where: { id: Number(id) },
      include: { items: true }
    });
    
    if (!collection) {
      return res.status(404).json({ error: 'Coleção não encontrada' });
    }
    
    res.json(collection);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar coleção', details: error });
  }
});

// POST - Criar uma nova coleção
router.post('/', async (req, res) => {
  try {
    const { name, description } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: 'Nome da coleção é obrigatório' });
    }
    
    const newCollection = await prisma.collection.create({
      data: {
        name,
        description
      }
    });
    
    res.status(201).json(newCollection);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao criar coleção', details: error });
  }
});

// PUT - Atualizar uma coleção existente
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: 'Nome da coleção é obrigatório' });
    }
    
    const updatedCollection = await prisma.collection.update({
      where: { id: Number(id) },
      data: {
        name,
        description
      }
    });
    
    res.json(updatedCollection);
  } catch (error) {
    if (error.code === 'P2025') {
      return res.status(404).json({ error: 'Coleção não encontrada' });
    }
    res.status(500).json({ error: 'Erro ao atualizar coleção', details: error });
  }
});

// DELETE - Remover uma coleção
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    await prisma.collection.delete({
      where: { id: Number(id) }
    });
    
    res.status(204).send();
  } catch (error) {
    if (error.code === 'P2025') {
      return res.status(404).json({ error: 'Coleção não encontrada' });
    }
    res.status(500).json({ error: 'Erro ao excluir coleção', details: error });
  }
});

export default router;
