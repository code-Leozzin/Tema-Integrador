import { PrismaClient } from '@prisma/client';

// Instância global do PrismaClient para evitar múltiplas conexões
const prisma = new PrismaClient();

export default prisma;
