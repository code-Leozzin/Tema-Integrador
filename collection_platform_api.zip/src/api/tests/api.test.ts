import axios from 'axios';

// Arquivo para testar os endpoints da API
const API_URL = 'http://localhost:3001/api';

// Função para testar a criação de uma coleção
async function testCreateCollection() {
  try {
    const response = await axios.post(`${API_URL}/collections`, {
      name: 'Minha Coleção de Teste',
      description: 'Uma coleção para testar a API'
    });
    
    console.log('Coleção criada com sucesso:');
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.error('Erro ao criar coleção:', error.response?.data || error.message);
    throw error;
  }
}

// Função para testar a listagem de coleções
async function testListCollections() {
  try {
    const response = await axios.get(`${API_URL}/collections`);
    
    console.log('Lista de coleções:');
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.error('Erro ao listar coleções:', error.response?.data || error.message);
    throw error;
  }
}

// Função para testar a criação de um item
async function testCreateItem(collectionId) {
  try {
    const response = await axios.post(`${API_URL}/items`, {
      name: 'Item de Teste',
      description: 'Um item para testar a API',
      imageUrl: 'https://example.com/image.jpg',
      collectionId
    });
    
    console.log('Item criado com sucesso:');
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.error('Erro ao criar item:', error.response?.data || error.message);
    throw error;
  }
}

// Função para testar a listagem de itens
async function testListItems() {
  try {
    const response = await axios.get(`${API_URL}/items`);
    
    console.log('Lista de itens:');
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.error('Erro ao listar itens:', error.response?.data || error.message);
    throw error;
  }
}

// Função para testar a atualização de uma coleção
async function testUpdateCollection(collectionId) {
  try {
    const response = await axios.put(`${API_URL}/collections/${collectionId}`, {
      name: 'Coleção Atualizada',
      description: 'Descrição atualizada da coleção'
    });
    
    console.log('Coleção atualizada com sucesso:');
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.error('Erro ao atualizar coleção:', error.response?.data || error.message);
    throw error;
  }
}

// Função para testar a exclusão de um item
async function testDeleteItem(itemId) {
  try {
    const response = await axios.delete(`${API_URL}/items/${itemId}`);
    
    console.log('Item excluído com sucesso');
    return true;
  } catch (error) {
    console.error('Erro ao excluir item:', error.response?.data || error.message);
    throw error;
  }
}

// Função para executar todos os testes em sequência
async function runAllTests() {
  try {
    console.log('Iniciando testes da API...');
    
    // Criar uma coleção
    const collection = await testCreateCollection();
    
    // Listar coleções
    await testListCollections();
    
    // Criar um item na coleção
    const item = await testCreateItem(collection.id);
    
    // Listar itens
    await testListItems();
    
    // Atualizar a coleção
    await testUpdateCollection(collection.id);
    
    // Excluir o item
    await testDeleteItem(item.id);
    
    console.log('Todos os testes concluídos com sucesso!');
  } catch (error) {
    console.error('Erro durante os testes:', error);
  }
}

// Executar os testes
runAllTests();
